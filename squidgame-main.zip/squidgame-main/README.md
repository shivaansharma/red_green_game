# Squid Game
## Red Light Green Light

Simple game based of on a popular Netfilx seires called "Squid Game".

## [Play Game Here](https://0shuvo0.github.io/squidgame/)

[Check Tutorial on Youtube:]((https://youtu.be/7bTuSZ94F6A))
[![Youtube Tutorial](img/preview.png)](https://youtu.be/7bTuSZ94F6A)